# Subjectivity-Mining
Assignments of Subjectivity Mining
